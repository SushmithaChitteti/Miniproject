create table Users1_miniproj27
(
UserId int identity primary key,
LoginId varchar(50) not null unique,
Password varchar(50)
)
select *from Users1_miniproj27
insert into Users1_miniproj27 values('Sushmitha','sush1234')
insert into Users1_miniproj27 values('Subhangi','s1234')

create proc LoginDetails_mp27(
@LoginId varchar(50) ,
@Password varchar(50) 
)
as
begin 
select LoginId,Password from Users1_miniproj27 where LoginId=@LoginId and Password=@Password 
end

create table travelRequests_miniproj27(
RequestId int identity not null,
RequestDate date not null,
FromLocation varchar(20) not null,
ToLocation varchar(50) not null,
CurrentStatus varchar(150)  ,
UserId int not null
)
select *from travelRequests_miniproj27
insert into travelRequests_miniproj27 values('6/10/2018','Pune','Hyderabad','null','1')
insert into travelRequests_miniproj27 values('6/12/2018','Hyderabad','pune','null','2')


create proc booking_161719(
@requestDate date,
@FromLocation varchar(20),
@ToLocation varchar(20),
@UserId int
)
as
begin
select RequestDate,FromLocation,ToLocation,UserId from travelRequests_miniproj27 where RequestDate=@requestDate and FromLocation=@FromLocation and ToLocation=@ToLocation and UserId=@UserId
end
exec proc 
 
 create table adminLoginDetails_mini27(
 LoginId varchar(20) not null,
 Password varchar(50) not null
 )
 insert into adminLoginDetails_mini27 values('admin','admin')

  create table ManagerLoginDetails_mini27(
 LoginId varchar(20) not null,
 Password varchar(50) not null
 )
 insert into ManagerLoginDetails_mini27 values('admin','admin')