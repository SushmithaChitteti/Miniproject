﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for managerPage.xaml
    /// </summary>
    public partial class managerPage : Window
    {
        private string user;
        private string password;
        public managerPage()
        {
            InitializeComponent();
        }
        public managerPage(string user,string password)
        {
            this.user= user;
            this.password = password;
            InitializeComponent();
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = null;
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.ManagerDisplay";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@ManagerName", txtManagerId.Text);
           
            
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
          
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
                dgDisplay.ItemsSource = dt.DefaultView;
            }
            else
            {
                MessageBox.Show("No Requests");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = null;
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.updateStatusByManager";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@EmployeeId", txtEmpId.Text);
            cmd.Parameters.AddWithValue("@Currentstatus", "Manager Approved");
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Status updated");
            }
            else
            {
                MessageBox.Show("not found");
            }

        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.updateStatusByManager";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@EmployeeId", txtEmpId.Text);
            cmd.Parameters.AddWithValue("@Currentstatus", "Manager Rejected");
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Status updated");
            }
            else
            {
                MessageBox.Show("not found");
            }

        }
    }
}
