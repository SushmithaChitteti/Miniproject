﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for Agent.xaml
    /// </summary>
    public partial class Agent : Window
    {
        public Agent()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
          
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.updateStatusByTravelAgent";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@RequestId",txtEmpId.Text);
            cmd.Parameters.AddWithValue("@Currentstatus", "Ticket Confirmed");
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Status updated");
            }
            else
            {
                MessageBox.Show("not found");
            }
        }

        private void Button_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void DgBookings_Loaded(object sender, RoutedEventArgs e)
        {
          
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = null;
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.DisplayRequestForAgent";

            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
                dgBookings.ItemsSource = dt.DefaultView;
            }
            else
            {
                MessageBox.Show("No Requests");
            }
        }

        private void Button_Copy_Click(object sender, RoutedEventArgs e)
        {

            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.updateStatusByTravelAgent";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@RequestId", txtEmpId.Text);
            cmd.Parameters.AddWithValue("@Currentstatus", "Tickets Not available");
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Status updated");
            }
            else
            {
                MessageBox.Show("not found");
            }
        }
    }
}
