﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Miniproject
{
    public class Locationsclass
    {
        public enum FromLocation
        {
            Hyderabad,Pune,Bangalore,Chennai,Mumbai
        }
        public enum ToLocation
        {
            Hyderabad, Pune, Bangalore, Chennai, Mumbai
        }
    }
}
