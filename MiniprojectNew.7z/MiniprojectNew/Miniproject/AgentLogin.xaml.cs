﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for AgentLogin.xaml
    /// </summary>
    public partial class AgentLogin : Window
    {
        public AgentLogin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand($"Select *from mini.Agentlogin where AgentUsername='"+ txtUname.Text+"' and AgentPass='"+ txtpwd.Text+"'",con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();

                MessageBox.Show("Logged in");
                var win2 = new Agent();
                win2.Show();
            }
            else
            {
                MessageBox.Show("Invalid");
            }
            con.Close();
        }
    }
}
