﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for TicketBooking.xaml
    /// </summary>

    public partial class TicketBooking : Window
    {
        public TicketBooking()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.bookingRequest";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.Add("@RequestId", SqlDbType.Int);
            cmd.Parameters["@RequestId"].Direction = ParameterDirection.Output;
            cmd.Parameters.AddWithValue("@requestDate", dataPicker.Text);
            cmd.Parameters.AddWithValue("@FromLocation", cmbFromLocation.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@ToLocation", cmbToLocation.Text);
            cmd.Parameters.AddWithValue("@employeeId", txtUserId.Text);
            cmd.Parameters.AddWithValue("@ManagerName", txtManagerId.Text);
            int a = cmd.ExecuteNonQuery();
            
            MessageBox.Show("Details Submitted! wait for the confirmation");
            con.Close();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var item in Enum.GetValues(typeof(FromLocation)))
            {
                cmbFromLocation.Items.Add(item);
            }
            foreach (var item in Enum.GetValues(typeof(ToLocation)))
            {
                cmbToLocation.Items.Add(item);
            }
        }

        private void CmbToLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CmbFromLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.Cancelrequest";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@employeeId", txtUserId.Text);
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Deleted");
            }
            else
            {
                MessageBox.Show("not found");
            }


          
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = null;
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.DisplayEmpRequest";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@employeeId", txtUserId.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
                DgDisplay.ItemsSource = dt.DefaultView;
            }
            else
            {
                MessageBox.Show("No bookings");
            }
        }

        private void TxtEID_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
    enum FromLocation
        {
            Hyderabad, Pune, Bangalore, Chennai, Mumbai
        }
        enum ToLocation
        {
            Hyderabad, Pune, Bangalore, Chennai, Mumbai
        }
    
}
