﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Window
    {
        public AdminPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var detailspage = new AddEmployee();
            detailspage.Show();
            this.Close();
        }

        private void Button_Copy_Click(object sender, RoutedEventArgs e)
        {

            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.AddTravelAgent";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@AgentName", txtAgentName.Text);
            cmd.Parameters.AddWithValue("@Username", txtAlogin.Text);
            cmd.Parameters.AddWithValue("@Password",txtAPawd.Text);
            int s = cmd.ExecuteNonQuery();
            MessageBox.Show("Agent Added");
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.DeleteEmployee";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@employeeId", txtEmpID.Text);
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Deleted");
            }
            else
            {
                MessageBox.Show("not found");
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnAssignmanager_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.AssignManager1";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@EmployeeId", txtEmpID.Text);
            cmd.Parameters.AddWithValue("@ManagerName", txtManagerName.Text);
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            if (noOfRowsAffected == 1)
            {
                MessageBox.Show("Manager Assigned");
            }
            else
            {
                MessageBox.Show("not found");
            }
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
    }
}
