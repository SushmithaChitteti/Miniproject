﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for EmployeeForm.xaml
    /// </summary>
    public partial class EmployeeForm : Window
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasCancelRequest.Visibility = Visibility.Hidden;
            CanvasDisplayRequest.Visibility = Visibility.Hidden;
            CanvasTicketBook.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasTicketBook.Visibility = Visibility.Hidden;
            CanvasDisplayRequest.Visibility = Visibility.Hidden;
            CanvasCancelRequest.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasCancelRequest.Visibility = Visibility.Hidden;
            CanvasTicketBook.Visibility = Visibility.Hidden;
            CanvasDisplayRequest.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            EmployeeForm mw = new EmployeeForm();
            mw.Show();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
        }
    }
}
