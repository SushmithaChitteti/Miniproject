﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Visible;
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlcon = new SqlConnection(ConfigurationManager.ConnectionStrings["Training_19Sep18_PuneConnectionString"].ConnectionString))
            {
                string query = "select count(1) from TusharProject.AdminLogin where LoginId=@LoginId AND Pass=@Pass";
                SqlCommand cmd = new SqlCommand(query, sqlcon);
                sqlcon.Open();
                cmd.Parameters.AddWithValue("@LoginId", txtAdminId.Text.Trim());
                cmd.Parameters.AddWithValue("@Pass", txtAdminpass.Text.Trim());
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                   AdminForm newWindow = new AdminForm();
                    newWindow.Show();
                }
                else
                {
                    lblAdminLogin.Content = "User not Found";
                }
            }
        }

        private void textBox_Copy_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasTravelAgent.Visibility = Visibility.Visible;
        }

        private void btnEmployeeLogin_Click(object sender, RoutedEventArgs e)
        {
            EmployeeForm ef = new EmployeeForm();
            ef.Show();
        }

        private void btnManagerLogin_Click(object sender, RoutedEventArgs e)
        {
            ManagerForm mf = new ManagerForm();
            mf.Show();
        }

        private void btnTravelAgentLogin_Click(object sender, RoutedEventArgs e)
        {
            TravelAgentForm taf = new TravelAgentForm();
            taf.Show();
        }
    }
}
